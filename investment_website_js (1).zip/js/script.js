let balance = 0;

function invest(packageName, amount) {
    alert(`You have invested in the ${packageName} package for Ksh ${amount}`);
    balance += amount * 0.1; // Simulating daily return
    updateBalance();
}

function deposit() {
    let amount = prompt("Enter amount to deposit:");
    if (amount && !isNaN(amount) && amount > 0) {
        alert(`Send Ksh ${amount} to Till Number 8110212 via Lipa na M-Pesa.`);
        balance += parseInt(amount);
        updateBalance();
    } else {
        alert("Invalid deposit amount.");
    }
}

function withdraw() {
    let amount = prompt("Enter amount to withdraw:");
    if (amount && !isNaN(amount) && amount > 0 && amount <= balance) {
        alert(`You have withdrawn Ksh ${amount}. It will be processed shortly.`);
        balance -= parseInt(amount);
        updateBalance();
    } else {
        alert("Invalid withdrawal amount or insufficient balance.");
    }
}

function updateBalance() {
    document.getElementById("balance").innerText = balance;
}

function copyReferral() {
    let link = `https://investment-website.com/referral?user=12345`;
    document.getElementById("referralLink").value = link;
    navigator.clipboard.writeText(link);
    alert("Referral link copied!");
}
